package src;

import java.util.ArrayList;
import java.util.function.Consumer;

public class Estoque {
    private ArrayList<Produtos> listaProdutos;

    public Estoque() {
        listaProdutos = new ArrayList<>();
    }

    public void adicionarProduto(Produtos produto) {
        for (Produtos p : listaProdutos) {
            if (p.getNome().equalsIgnoreCase(produto.getNome())) {
                p.setQuantidade(p.getQuantidade() + produto.getQuantidade());
                return;
            }
        }
        listaProdutos.add(produto);
    }

    public boolean removerProduto(String nome, int quantidade) {
        for (Produtos p : listaProdutos) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                if (p.getQuantidade() >= quantidade) {
                    p.setQuantidade(p.getQuantidade() - quantidade);
                    if (p.getQuantidade() == 0) {
                        listaProdutos.remove(p);
                    }
                    return true;
                }
                return false; // Quantidade insuficiente
            }
        }
        return false; // Produto não encontrado
    }

    public void consultarEstoque(Consumer<String> consumidor) {
        if (listaProdutos.isEmpty()) {
            consumidor.accept("Estoque vazio.\n");
        } else {
            consumidor.accept("Produtos no estoque:\n");
            for (Produtos p : listaProdutos) {
                consumidor.accept(p.toString() + "\n");
            }
        }
    }

    public Produtos buscarProduto(String nome) {
        for (Produtos p : listaProdutos) {
            if (p.getNome().equalsIgnoreCase(nome)) {
                return p;
            }
        }
        return null; // Produto não encontrado
    }
}
