package src;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class EstoqueView {
    private final Estoque estoque;
    private final VBox root;

    public EstoqueView() {
        estoque = new Estoque();
        root = new VBox();
        root.setPadding(new Insets(10));
        root.setSpacing(10);

        Text title = new Text("Controle de Estoque - PetShop");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        Button btnAdicionar = new Button("Adicionar Produto");
        Button btnRemover = new Button("Remover Produto");
        Button btnConsultar = new Button("Consultar Estoque");
        Button btnBuscar = new Button("Buscar Produto");

        TextArea output = new TextArea();
        output.setEditable(false);

        btnAdicionar.setOnAction(e -> adicionarProduto(output));
        btnRemover.setOnAction(e -> removerProduto(output));
        btnConsultar.setOnAction(e -> consultarEstoque(output));
        btnBuscar.setOnAction(e -> buscarProduto(output));

        HBox buttonBox = new HBox(10, btnAdicionar, btnRemover, btnConsultar, btnBuscar);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        root.getChildren().addAll(title, buttonBox, output);
    }

    public VBox getRoot() {
        return root;
    }

    private void adicionarProduto(TextArea output) {
        Dialog<Produtos> dialog = new Dialog<>();
        dialog.setTitle("Adicionar Produto");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nomeField = new TextField();
        nomeField.setPromptText("Nome");
        TextField quantidadeField = new TextField();
        quantidadeField.setPromptText("Quantidade");
        TextField precoField = new TextField();
        precoField.setPromptText("Preço");

        grid.add(new Label("Nome:"), 0, 0);
        grid.add(nomeField, 1, 0);
        grid.add(new Label("Quantidade:"), 0, 1);
        grid.add(quantidadeField, 1, 1);
        grid.add(new Label("Preço:"), 0, 2);
        grid.add(precoField, 1, 2);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                try {
                    String nome = nomeField.getText();
                    int quantidade = Integer.parseInt(quantidadeField.getText());
                    double preco = Double.parseDouble(precoField.getText());
                    return new Produtos(nome, quantidade, preco);
                } catch (NumberFormatException ex) {
                    output.setText("Erro: Verifique os valores inseridos.");
                }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(produto -> {
            estoque.adicionarProduto(produto);
            output.setText("Produto adicionado: " + produto);
        });
    }

    private void removerProduto(TextArea output) {
        Dialog<String[]> dialog = new Dialog<>();
        dialog.setTitle("Remover Produto");

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField nomeField = new TextField();
        nomeField.setPromptText("Nome");
        TextField quantidadeField = new TextField();
        quantidadeField.setPromptText("Quantidade");

        grid.add(new Label("Nome:"), 0, 0);
        grid.add(nomeField, 1, 0);
        grid.add(new Label("Quantidade:"), 0, 1);
        grid.add(quantidadeField, 1, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                return new String[]{nomeField.getText(), quantidadeField.getText()};
            }
            return null;
        });

        dialog.showAndWait().ifPresent(data -> {
            String nome = data[0];
            int quantidade;
            try {
                quantidade = Integer.parseInt(data[1]);
                boolean sucesso = estoque.removerProduto(nome, quantidade);
                if (sucesso) {
                    output.setText("Produto removido com sucesso.");
                } else {
                    output.setText("Erro: Produto não encontrado ou quantidade insuficiente.");
                }
            } catch (NumberFormatException ex) {
                output.setText("Erro: Quantidade inválida.");
            }
        });
    }

    private void consultarEstoque(TextArea output) {
        StringBuilder sb = new StringBuilder();
        estoque.consultarEstoque(sb::append);
        output.setText(sb.toString());
    }

    private void buscarProduto(TextArea output) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Buscar Produto");
        dialog.setHeaderText("Digite o nome do produto:");
        dialog.setContentText("Nome:");

        dialog.showAndWait().ifPresent(nome -> {
            Produtos produto = estoque.buscarProduto(nome);
            if (produto != null) {
                output.setText("Produto encontrado:\n" + produto);
            } else {
                output.setText("Produto não encontrado.");
            }
        });
    }
}
